"""MCP Server for PostgreSQL access."""
from .postgres_server import PostgresMCPServer

__all__ = ["PostgresMCPServer"]
